// // Imports
var models   = require('../models');
var asyncLib = require('async');
var jwtUtils = require('../utils/jwt.utils');

// // Constants
const ITEMS_LIMIT   = 50;

// // Routes
module.exports = {
    createLocal: function(req, res) {
    // Getting auth header
    var headerAuth  = req.headers['authorization'];
    var userId      = jwtUtils.getUserId(headerAuth);

    // Params
    var region   = req.body.region;
    var localite = req.body.localite;
    var adresse   = req.body.adresse;
    var type   = req.body.type;
    var photo1   = req.body.photo1;
    var photo2   = req.body.photo2;
    var photo3   = req.body.photo3;
    var tarif=req.body.tarif;

    if (region == null ||localite == null ||photo1 == null || tarif == null ) {
        return res.status(400).json({ 'error': 'missing parameters' });
    }

    if (region.length <= 4 || region.length >= 20) {
        return res.status(400).json({ 'error': ' pas de région de ce format' });
    }

    if (localite.length <= 3 || localite.length >= 30) {
        return res.status(400).json({ 'error': ' pas de localité de ce format' });
    }

    asyncLib.waterfall([
        function(done) {
        models.User.findOne({
            where: { id: userId }
        })
        .then(function(userFound) {
            done(null, userFound);
        })
        .catch(function(err) {
            return res.status(500).json({ 'error': 'unable to verify user' });
        });
        },
        function(userFound, done) {
        if(userFound) {
            models.Local.create({
            region  : region,
            localite: localite,
            adresse  : adresse,
            type:type,
            tarif:tarif,
            photo1:photo1,
            photo2:photo2,
            photo3:photo3,
            UserId : userFound.id
            })
            .then(function(newLocal) {
            done(newLocal);
            });
        } else {
            res.status(404).json({ 'error': 'user not found' });
        }
        },
    ], function(newLocal) {
        if (newLocal) {
        return res.status(201).json(newLocal);
        } else {
        return res.status(500).json({ 'error': 'cannot post Local' });
        }
    });
    },

    // Lister les chambres
    listLocals: function(req, res) {
        var fields  = req.query.fields;
        var limit   = parseInt(req.query.limit);
        var offset  = parseInt(req.query.offset);
        var order   = req.query.order;

        if (limit > ITEMS_LIMIT) {
        limit = ITEMS_LIMIT;
        }

        models.Local.findAll({
        order: [(order != null) ? order.split(':') : ['region', 'ASC']],
        attributes: (fields !== '*' && fields != null) ? fields.split(',') : null,
        limit: (!isNaN(limit)) ? limit : null,
        offset: (!isNaN(offset)) ? offset : null,
        include: [{
            model: models.User,
            attributes: [ 'username' ]
        }]
        }).then(function(locals) {
        if (locals) {
            res.status(200).json(locals);
        } else {
            res.status(404).json({ "error": "no locals found" });
        }
        }).catch(function(err) {
        console.log(err);
        res.status(500).json({ "error": "invalid fields" });
        });
    }
}