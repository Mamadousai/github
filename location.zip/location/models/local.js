'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Local extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      models.Local.belongsTo(models.User,{
        foreignKey: {
          allowNull: false
        }
      })
    }
  }
  Local.init({
    region: DataTypes.STRING,
    localite: DataTypes.STRING,
    adresse: DataTypes.STRING,
    type: DataTypes.STRING,
    photo1: DataTypes.STRING,
    photo2: DataTypes.STRING,
    photo3: DataTypes.STRING,
    tarif: DataTypes.INTEGER,
  }, {
    sequelize,
    modelName: 'Local',
  });
  return Local;
};