// Imports
var express      = require('express');
var usersCtrl    = require('./controller/usersCtrl');
var localsCtrl = require('./controller/localsCtrl');

// Router
exports.router = (function() {
  var apiRouter = express.Router();

  // Users routes
  apiRouter.route('/users/register/').post(usersCtrl.register);
  // pour tester on prend (http://localhost:8080/api/users/register)

  apiRouter.route('/users/login/').post(usersCtrl.login);
  // pour tester on prend (http://localhost:8080/api/users/login)

  apiRouter.route('/users/me/').get(usersCtrl.getUserProfile);
  // pour tester on prend (http://localhost:8080/api/users/me)

  //apiRouter.route('/users/me/').put(usersCtrl.updateUserProfile);

  // // Local routes
  apiRouter.route('/locals/new/').post(localsCtrl.createLocal);
  // pour tester on prend (http://localhost:8080/api/locals/new)

  apiRouter.route('/locals/').get(localsCtrl.listLocals);

  
  return apiRouter;
})();